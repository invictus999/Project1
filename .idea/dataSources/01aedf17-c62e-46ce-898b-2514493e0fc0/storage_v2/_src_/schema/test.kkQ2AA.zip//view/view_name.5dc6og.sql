create view view_name as
  select
    `test`.`persons`.`id_p`      AS `id_p`,
    `test`.`persons`.`LastName`  AS `LastName`,
    `test`.`persons`.`FirstName` AS `FirstName`
  from `test`.`persons`
  where (`test`.`persons`.`id_p` >= 2);

